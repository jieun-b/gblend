import bpy
from mathutils import Vector

def place_object(glb_path: str, set_active=True):
    """Import GLB, group under Empty, preserve materials, normalize scale."""

    bpy.ops.import_scene.gltf(filepath=glb_path)
    bpy.context.view_layer.update()

    imported_objs = bpy.context.selected_objects
    if not imported_objs:
        print("[WARN] No imported objects.")
        return None

    # 1) 하나의 Empty 컨테이너 생성
    container = bpy.data.objects.new("ImportedObject", None)
    bpy.context.scene.collection.objects.link(container)

    # 2) 기존 계층은 유지하면서 '부모만' Empty로 교체
    for obj in imported_objs:
        obj.matrix_parent_inverse = container.matrix_world.inverted()
        obj.parent = container  # Material 영향 없음

    bpy.context.view_layer.update()

    # 3) Mesh만 가져와서 bounding box 계산
    meshes = [obj for obj in imported_objs if obj.type == 'MESH']
    if not meshes:
        print("[WARN] No meshes.")
        return container

    all_coords = []
    for obj in meshes:
        for v in obj.bound_box:
            all_coords.append(obj.matrix_world @ Vector(v))

    xs = [c.x for c in all_coords]
    ys = [c.y for c in all_coords]
    zs = [c.z for c in all_coords]

    size = max(max(xs)-min(xs), max(ys)-min(ys), max(zs)-min(zs))
    scale = 0.5 / size if size > 0 else 1.0

    # 4) Empty에만 스케일 적용 → Mesh/material 안전
    container.scale = (scale, scale, scale)
    container.location = (0, 0, -0.3)

    # 5) 선택 설정
    if set_active:
        bpy.ops.object.select_all(action='DESELECT')
        container.select_set(True)
        bpy.context.view_layer.objects.active = container

    return container
