GAUSSIAN_SERVER_URL = "http://localhost:8000"
GROUNDED_SAM_SERVER_URL = "http://localhost:8001"
OBJAVERSE_SERVER_URL = "http://localhost:8002"
